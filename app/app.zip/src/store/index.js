import {createStore, combineReducers, applyMiddleware } from 'redux'
import { categoryReducer } from './reducer/categoryReducer'
import thunk from 'redux-thunk'


const rootReducer = combineReducers ({
    categories: categoryReducer
})

export const store = createStore(rootReducer, applyMiddleware(thunk))