

const initialState = ["electronics","jewelery","men's clothing","women's clothing"]


const LOAD = 'LOAD'


export const loadAction = payload => ({type: LOAD, payload})

export const categoryReducer = (state = [], action) => {
    if(action.type === LOAD){
        return action.payload
    }
    return state
}






