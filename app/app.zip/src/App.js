import { useDispatch } from 'react-redux';
import './App.css';
import CategoryList from './components/CategoryList';
import { fetchCategory } from './asyncAction/categoryAction';
import { useEffect } from 'react';

function App() {

  const dispatch = useDispatch();

  useEffect(() =>{
    dispatch(fetchCategory)
  }, [dispatch])


  return (
    <div>
     <CategoryList />
    </div>
  );
}

export default App;
