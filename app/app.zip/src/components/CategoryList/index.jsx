import React from 'react'
import { useSelector } from 'react-redux'
import CategoryItem from '../CategoryItem'
import s from './index.module.css'

export default function CategoryList() {

    const category = useSelector(state => state.categories)

  return (
    <div className={s.wrapper}>
        {
            category.map(item => <CategoryItem key={item} props={item} />)
        }
    </div>
  )
}
