import React from 'react'
import s from './index.module.css'

export default function CategoryItem({props}) {
  return (
    <div className={s.item}>
        <p>{props}</p>
    </div>
  )
}
