import { loadAction } from "../store/reducer/categoryReducer"


export const fetchCategory = (dispatch) => {
    fetch('https://fakestoreapi.com/products/categories')
    .then(resp => resp.json())
    .then(data => dispatch(loadAction(data)))
}